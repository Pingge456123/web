// 瀑布流
$(window).on('load',function(){

	waterfull();

	$('.empty').click(function() {
   $(this).html('<span class="glyphicon glyphicon-heart">');
})

});
function waterfull(){
	
	var w=$('.box').eq(0).width();
	var cols=Math.floor($(window).width()/w);
	

	$('#content').width(cols*w);
	var hArr=[];
	$('.box').each(function(index,value){
		var h = $('.box').eq(index).outerHeight();
		if(index<cols){
				hArr[index]=h;

		}else{
			var minH=Math.min.apply(null,hArr);
			var minHIndex=$.inArray(minH,hArr);
			$(value).css({
				'position':'absolute',
				'top':minH+'px',
				'left':minHIndex*w+'px'
			})
			hArr[minHIndex]+=$('.box').eq(index).outerHeight();
		}

		$('#content').height(6/cols*1000);

	})
	console.log(hArr);


};
	
  // function empty(){
  // 	// $('.empty').html('<span class="glyphicon glyphicon-heart">');
  // 	// alert($(this).index())
  // }
