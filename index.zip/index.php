<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>demo</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="http://libs.baidu.com/jquery/2.1.4/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/mian.js"></script>
	
</head>
<body>
	<div id="head">
		<a href="#" class="logo"><img src="ui/images/1111_03.png"></a>
		<ul class="menu"><li>
			<a href="#" class="active"><del>HOME</del></a>
		
		</li>
		<li>
			<a href="#">BLOG</a>
			
		</li>
		<li>
			<a href="#">PORITFOLIO</a>
			
		</li>
		<li>
			<a href="#">FEATURES</a>
			
		</li>
		<li>
			<a href="#">PRICNG</a>
			
		</li></ul>
		<div class="right"><a href="#"><img src="ui/images/1111_06.png"></a>
		<a href="#"><img src="ui/images/1111_08.png"></a>
	<a href="#"><img src="ui/images/1111_11.png"></a></div>
	<h1 class="one">Start with</h1><h1 class="two">Barni</h1>
	</div>
	<!--  瀑布流 --> 
	<div id="content">
		<div class="box">
			<img src="images/1_05.png" width="480px">
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>1M+ Possibilities</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p><br><p>
			For now, but he’ll come around. In the meantime there’s the matter of your brother-in-law. He is a problem you promised to resolve. You have failed. Now is left to me. To deal with him. If you try to interfere, this becomes a much simpler matter. I will kill your wife, I will kill your son, I will kill your infant daughter</p>
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<button type="button" class="btn btn-default" data-container="body" data-toggle="popover" data-placement="top" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."><span class="glyphicon glyphicon-edit"></span></button><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
		</div>
	<!-- 	第二章 -->
		<div class="box">
			
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>New Wordpress Theme</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.
</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p><br><p>
			For now, but he’ll come around. In the meantime there’s the matter of your brother-in-law. He is a problem you promised to resolve. You have failed. Now is left to me. To deal with him. If you try to interfere, this becomes a much simpler matter. I will kill your wife, I will kill your son, I will kill your infant daughter</p>
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-edit"></span><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
			<img src="images/1_09.png" width="480px">
		</div>
		<!-- 第三章 -->
	<div class="box">
			<img src="images/1_03.png" width="480px">
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>Barni is Coming</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p>
		
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-edit"></span><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
		</div>
		<!-- 第四章 -->
		<div class="box">
			<img src="images/1_11.png" width="480px">
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>1M+ Possibilities</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p><br><p>
			For now, but he’ll come around. In the meantime there’s the matter of your brother-in-law. He is a problem you promised to resolve. You have failed. Now is left to me. To deal with him. If you try to interfere, this becomes a much simpler matter. I will kill your wife, I will kill your son, I will kill your infant daughter</p>
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-edit"></span><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
		</div>
		<!-- 第五章 -->
	<div class="box">
			
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>1M+ Possibilities</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p>
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-edit"></span><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
			<img src="images/1_13.png" width="480px">
		</div>

		<!-- 第六章 -->
		<div class="box">
			<img src="images/1_17.png" width="480px">
			<div class="box-p">
			<a>John Doe</a>/January 18 2015
			<h2>1M+ Possibilities</h2>
			<p>Don Eladio, please. I didn’t sell anything. I apologize if you are offended by my method of obtaining this meeting. I merely took the initiative.</p><br>
			<p>
			I meant no insult. You are done. Fired. Do not show your face at the laundry again. Stay away from Pinkman. Do not go near him. Ever. Are you listening to me? What do you say?</p><br><p>
			For now, but he’ll come around. In the meantime there’s the matter of your brother-in-law. He is a problem you promised to resolve. You have failed. Now is left to me. To deal with him. If you try to interfere, this becomes a much simpler matter. I will kill your wife, I will kill your son, I will kill your infant daughter</p>
			<br><br><br><br><br>
			<a href="javascript:void(0)" onclick="empty()" class="empty"><span class=" glyphicon glyphicon-heart-empty"></span></a>
				<strong>35</strong> 	 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-edit"></span><strong>18</strong> 	&nbsp; 		&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp; 	&nbsp;<span class="glyphicon glyphicon-share"></span>
			</span></div>
			
		</div>

		</div>
	

<!-- 这是个按钮 -->


	
	<div class="readmore">
	<button type="button" class="btn btn-primary btn-lg ">Read more</button></div>
	<!-- 幻灯片 -->
	<div id="slide">
	<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="images/1_19.png" alt="...">
      <div class="carousel-caption">
        ...
      </div>
    </div>
    <div class="item">
      <img src="images/1_19.png" alt="...">
      <div class="carousel-caption">
        
      </div>
    </div>
    
  </div>


</div></div>


	<!-- 第二部分内容 -->
	<div id="content2">
		<p class="p1">Barni is an elegant, modern and fully customizable Desktop UI Kit</p>
		<h1>BARNI</h1>
		<h2>Barni 丨</h2>
		<p class="p3"><strong><em>Barni is an elegant, modern and fully </em></strong></p>
		<p class="p4"><strong><em>customizable  Desktop UI Kit</em></strong></p>
		<a href="#" class="img1"><img src="images/1_22.png"></a>
		<a href="#" class="img2"><img src="images/1_25.png"></a>
		<a href="#" class="img3"><img src="images/1_30.png"></a>
		<a href="#" class="img4"><img src="images/1_33.png"></a>
		<a href="#" class="img5"><img src="images/1_35.png"></a>
		<a href="#" class="img6"><img src="images/1_40.png"></a>
		<a href="#" class="img7"><img src="images/1_46.png"></a>
		<a href="#" class="img8"><img src="images/1_48.png"></a>
		<a href="#" class="img9"><img src="images/1_43.png"></a>
		<div class="time">
			<p class="ddd">date</p><h3>6</h3>
			<p><em>January</em> 2018</p>

		</div>

	</div>
	<div id="foot">
	<img src="images/1_53.png">
	<blockquote class="blockquote-reverse">
  	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
  	<footer>Someone famous in <cite title="Source Title">Source Title</cite></footer>
	</blockquote>
	</div>

	

</body>
</html>